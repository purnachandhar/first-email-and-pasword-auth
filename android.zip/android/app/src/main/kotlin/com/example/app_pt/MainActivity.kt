package com.example.app_pt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
